﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Checkers
{
    public partial class Board : Form
    {
        private int counterCountWhite = 12;
        private int counterCountBlack = 12;
        private string colourOfTurn = "W";
        private int[] previouslyClicked = new int[2];
        Button[,] btn = new Button[8, 8];      // Create 2D array of buttons
        Box[,] bxArray = new Box[8, 8];
        private int[,] destinationAfterTake = new int[4, 2];
        private int[,] counterToBeTaken = new int[4, 2];
        private bool taken = false;
        public Board()
        {
            InitializeComponent();
            bool whiteSquare = true;
            for (int x = 0; x < btn.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < btn.GetLength(1); y++)     // Loop for y
                {
                    btn[x, y] = new Button();
                    btn[x, y].SetBounds(100 * x, 100 * y, 100, 100);
                    if (whiteSquare == false)
                    {
                        if (y < 3)
                        {
                            bxArray[x, y].populated = true;
                            bxArray[x, y].populatedBy = "W";     // W for white
                            //btn[x, y].Image = Image.FromFile("Annotation 2020-02-06 163221.png");
                        }
                        else if (y > 4)
                        {
                            bxArray[x, y].populated = true;
                            bxArray[x, y].populatedBy = "B";     // B for black
                            //btn[x, y].Image = Image.FromFile("Annotation 2020-02-06 163222.png");
                        }
                    }
                    if (whiteSquare == true)
                    {
                        btn[x, y].BackColor = Color.White;
                        bxArray[x, y].colour = "W";
                        whiteSquare = false;
                    }
                    else
                    {
                        btn[x, y].BackColor = Color.Black;
                        btn[x, y].ForeColor = Color.White;
                        bxArray[x, y].colour = "B";
                        whiteSquare = true;
                    }
                    btn[x, y].Name = Convert.ToString(x + "," + y + bxArray[x, y].populatedBy);
                    btn[x, y].Text = bxArray[x, y].populatedBy;
                    btn[x, y].Click += new EventHandler(this.btnEvent_Click);
                    Controls.Add(btn[x, y]);

                }
                if (whiteSquare == true)
                {
                    whiteSquare = false;
                }
                else
                {
                    whiteSquare = true;
                }
            }
        }

        void btnEvent_Click(object sender, EventArgs e)
        {
            Console.WriteLine("=======================");
            int x = int.Parse(((Button)sender).Name[0].ToString());
            int y = int.Parse(((Button)sender).Name[2].ToString());
            bool king = bxArray[x, y].king;

            if (((Button)sender).BackColor == Color.Blue)
            {
                // RefreshBoard();
                MakeMove(previouslyClicked[0], previouslyClicked[1], x, y, king);
                if (taken == false)
                {
                    RefreshBoard();
                }
                else
                {
                    previouslyClicked[0] = x;
                    previouslyClicked[1] = y;
                    RefreshBoard();
                    CheckAllMoves(x, y, king);
                }
            }
            else if (bxArray[x, y].populatedBy == colourOfTurn && taken == false)
            {
                RefreshBoard();
                CheckAllMoves(x, y, king);
                previouslyClicked[0] = x;
                previouslyClicked[1] = y;
            }
            if(CheckCounterCount() == false)
            {
                this.Close();
            }
        }

        // Gets coordinates and checks the moves that are available for a counter of a given colour from that square
        public void CheckAllMoves(int x, int y, bool king = false)
        {
            bool validMove = false;
            int limit = 2;

            if (king == true)
            {
                limit = 4;
            }
            /*
            if (bxArray[x, y].populatedBy == colourOfTurn)
            {
            */
            int[,] arrayOfMoves = new int[limit, 2];
            if (king == false)
            {
                if (colourOfTurn == "B")
                {
                    // the block diagonally to the left
                    arrayOfMoves[0, 0] = x - 1;
                    arrayOfMoves[0, 1] = y - 1;
                    // the block diagonally to the right
                    arrayOfMoves[1, 0] = x + 1;
                    arrayOfMoves[1, 1] = y - 1;
                }
                else
                {
                    // the block diagonally to the left
                    arrayOfMoves[0, 0] = x - 1;
                    arrayOfMoves[0, 1] = y + 1;
                    // the block diagonally to the right
                    arrayOfMoves[1, 0] = x + 1;
                    arrayOfMoves[1, 1] = y + 1;
                }
            }
            else
            {
                // the block diagonally to the left
                arrayOfMoves[0, 0] = x - 1;
                arrayOfMoves[0, 1] = y - 1;
                // the block diagonally to the right
                arrayOfMoves[1, 0] = x + 1;
                arrayOfMoves[1, 1] = y - 1;

                // the block diagonally to the left
                arrayOfMoves[2, 0] = x - 1;
                arrayOfMoves[2, 1] = y + 1;
                // the block diagonally to the right
                arrayOfMoves[3, 0] = x + 1;
                arrayOfMoves[3, 1] = y + 1;
            }
            // This doesn't matter for the king
            for (int i = 0; i < limit; i++)
            {
                // Checking that the square that we are testing is in range of the table, otherwise skip this square
                if (arrayOfMoves[i, 0] < 0 || arrayOfMoves[i, 1] < 0 || arrayOfMoves[i, 0] > 7 || arrayOfMoves[i, 1] > 7)
                {
                    continue;
                }
                // if there are no valid moves
                if (CheckMove(arrayOfMoves[i, 0], arrayOfMoves[i, 1]) == "N")
                {
                    Console.WriteLine("No move");
                    btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                }
                // if there is a valid move where one of the opposing players counters could be taken
                else if (CheckMove(arrayOfMoves[i, 0], arrayOfMoves[i, 1]) == "T")
                {
                    // Array.Clear(destinationAfterTake, 0, destinationAfterTake.Length);
                    // Array.Clear(counterToBeTaken, 0, counterToBeTaken.Length);
                    // needs to be a link to the new function here
                    // Console.WriteLine("Move available with taking");
                    if (king == true)
                    {
                        CheckMoveWithTakeKing(arrayOfMoves[i, 0], arrayOfMoves[i, 1], i, arrayOfMoves);
                    }
                    else
                    {
                        Console.WriteLine("Running check move with take");
                        if (validMove == false)
                        {
                            validMove = CheckMoveWithTake(arrayOfMoves[i, 0], arrayOfMoves[i, 1], i, arrayOfMoves);
                        }
                        else
                        {
                            CheckMoveWithTake(arrayOfMoves[i, 0], arrayOfMoves[i, 1], i, arrayOfMoves);
                        }
                    }
                }
                // if there is just a straight-forward move
                else if (CheckMove(arrayOfMoves[i, 0], arrayOfMoves[i, 1]) == "Y")
                {
                    // validMove = true;
                    Console.WriteLine("Move available");
                    btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Blue;
                }
            }
            Console.WriteLine("if statement: valid move is: " + validMove + " and taken is: " + taken);
            if (validMove == false && taken == true)
            {
                ChangeTurn();
                RefreshBoard();
                taken = false;
            }
            /*
        }
        else
        {
            Console.WriteLine("Input error in check all moves");
            return;
        }
        */
        }

        public void CheckMoveWithTakeKing(int x, int y, int i, int[,] arrayOfMoves)
        {
            // if it is checking to the left
            int[] boxToCheck = new int[2];
            try
            {
                if (i == 0)
                {
                    boxToCheck[0] = arrayOfMoves[i, 0] - 1;
                    boxToCheck[1] = arrayOfMoves[i, 1] - 1;
                }
                else if (i == 1)
                {
                    boxToCheck[0] = arrayOfMoves[i, 0] + 1;
                    boxToCheck[1] = arrayOfMoves[i, 1] - 1;
                }
                else if (i == 2)
                {
                    boxToCheck[0] = arrayOfMoves[i, 0] - 1;
                    boxToCheck[1] = arrayOfMoves[i, 1] + 1;
                }
                else if (i == 3)
                {
                    boxToCheck[0] = arrayOfMoves[i, 0] + 1;
                    boxToCheck[1] = arrayOfMoves[i, 1] + 1;
                }
                if (boxToCheck[0] >= 0 && boxToCheck[0] < 8 && boxToCheck[1] >= 0 && boxToCheck[1] < 8)
                {
                    if (bxArray[boxToCheck[0], boxToCheck[1]].populated == true)
                    {
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                        return;
                    }
                    else
                    {
                        destinationAfterTake[i, 0] = boxToCheck[0];
                        destinationAfterTake[i, 1] = boxToCheck[1];
                        counterToBeTaken[i, 0] = arrayOfMoves[i, 0];
                        counterToBeTaken[i, 1] = arrayOfMoves[i, 1];

                        btn[boxToCheck[0], boxToCheck[1]].BackColor = Color.Blue;
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Orange;
                    }
                }
                else
                {
                    btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                    return;
                }
            }
            catch (Exception e)
            {
                return;
            }
        }

        public bool CheckMoveWithTake(int x, int y, int i, int[,] arrayOfMoves)
        {
            // if it is checking to the left
            int[] boxToCheck = new int[2];
            try
            {
                if (i == 0)
                {
                    if (colourOfTurn == "B")
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] - 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] - 1;
                        // if (arrayOfMoves[i, 0] > 0 && arrayOfMoves[i, 1] > 0) { btn[arrayOfMoves[i, 0] - 1, arrayOfMoves[i, 1] - 1].BackColor = Color.Blue; }
                    }
                    else
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] - 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] + 1;
                        // if (arrayOfMoves[i, 0] > 0 && arrayOfMoves[i, 1] < 7) { btn[arrayOfMoves[i, 0] - 1, arrayOfMoves[i, 1] + 1].BackColor = Color.Blue; }
                    }
                }
                // if it is checking to the right
                else
                {
                    if (colourOfTurn == "B")
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] + 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] - 1;
                        // if (arrayOfMoves[i, 0] < 7 && arrayOfMoves[i, 1] > 0) { btn[arrayOfMoves[i, 0] + 1, arrayOfMoves[i, 1] - 1].BackColor = Color.Blue; }
                    }
                    else
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] + 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] + 1;
                        // if (arrayOfMoves[i, 0] < 7 && arrayOfMoves[i, 1] < 7) { btn[arrayOfMoves[i, 0] + 1, arrayOfMoves[i, 1] + 1].BackColor = Color.Blue; }
                    }
                }
                if (boxToCheck[0] >= 0 && boxToCheck[0] < 8 && boxToCheck[1] >= 0 && boxToCheck[1] < 8)
                {
                    if (bxArray[boxToCheck[0], boxToCheck[1]].populated == true)
                    {
                        Console.WriteLine("Box is populated: " + boxToCheck[0] + " " + boxToCheck[1]);
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                        return false;
                    }
                    else
                    {
                        Console.WriteLine("Box is not populated, move is available: " + boxToCheck[0] + " " + boxToCheck[1]);
                        destinationAfterTake[i, 0] = boxToCheck[0];
                        destinationAfterTake[i, 1] = boxToCheck[1];
                        counterToBeTaken[i, 0] = arrayOfMoves[i, 0];
                        counterToBeTaken[i, 1] = arrayOfMoves[i, 1];

                        btn[boxToCheck[0], boxToCheck[1]].BackColor = Color.Blue;
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Orange;
                        return true;
                    }
                }
                else
                {
                    btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                    return false;
                }
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public string CheckMove(int x, int y)
        {
            try
            {
                if (bxArray[x, y].populatedBy == colourOfTurn)
                {
                    return "N";
                }
                else if (bxArray[x, y].populated == true)
                {
                    // "T" for take (if it is populated and the colour is not the same as the colour of the player)
                    return "T";
                }
                else
                {
                    return "Y";
                }
            }
            catch (Exception e)
            {
                return "E";
            }
        }

        // This function is currently not in use
        /*
        public void TakeCounter()
        {
            for (int x = 0; x < bxArray.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < bxArray.GetLength(1); y++)     // Loop for y
                {
                    if (btn[x, y].BackColor == Color.Orange)
                    {
                        bxArray[x, y].populated = false;
                        bxArray[x, y].populatedBy = "";
                    }       
                }
            }
        }
        */

        public void RefreshBoard()
        {
            for (int x = 0; x < bxArray.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < bxArray.GetLength(1); y++)     // Loop for y
                {
                    // This is the bit that doesn't work
                    /*
                    if (btn[x, y].BackColor == Color.Orange)
                    {
                        bxArray[x, y].populated = false;
                        bxArray[x, y].populatedBy = "";
                    }
                    */
                    if (bxArray[x, y].colour == "W")
                    {
                        btn[x, y].BackColor = Color.White;
                    }
                    else
                    {
                        btn[x, y].BackColor = Color.Black;
                    }
                    btn[x, y].Name = Convert.ToString(x + "," + y + bxArray[x, y].populatedBy);
                    btn[x, y].Text = bxArray[x, y].populatedBy;
                }
            }
        }

        public void SwapPositions(int ogX, int ogY, int x, int y)
        {
            string tempPopulatedBy = bxArray[x, y].populatedBy;
            bool tempPopulated = bxArray[x, y].populated;
            bool tempKing = bxArray[x, y].king;
            Color tempColour = btn[x, y].ForeColor;

            bxArray[x, y].populatedBy = bxArray[ogX, ogY].populatedBy;
            bxArray[x, y].populated = bxArray[ogX, ogY].populated;
            bxArray[x, y].king = bxArray[ogX, ogY].king;
            btn[x, y].ForeColor = btn[ogX, ogY].ForeColor;

            bxArray[ogX, ogY].populatedBy = tempPopulatedBy;
            bxArray[ogX, ogY].populated = tempPopulated;
            bxArray[ogX, ogY].king = tempKing;
            btn[ogX, ogY].ForeColor = tempColour;
        }

        public void MakeMove(int ogX, int ogY, int x, int y, bool king = false)
        {

            int limit = 4;

            if (king == true)
            {
                limit = 4;
            }

            if (btn[x, y].BackColor == Color.Blue)
            {
                /*
                bxArray[x, y].populatedBy = colourOfTurn;
                bxArray[x, y].populated = true;
                bxArray[x, y].king = bxArray[ogX, ogY].king;

                bxArray[ogX, ogY].populatedBy = "";
                bxArray[ogX, ogY].populated = false;
                bxArray[ogX, ogY].king = false;
                */

                SwapPositions(ogX, ogY, x, y);

                if (colourOfTurn == "B" && y == 0)
                {
                    bxArray[x, y].king = true;
                    btn[x, y].ForeColor = Color.Gold;
                }
                else if (colourOfTurn == "W" && y == 7)
                {
                    bxArray[x, y].king = true;
                    btn[x, y].ForeColor = Color.Gold;
                }
            }
            else
            {
                return;
            }

            int i = 0;
            for (i = 0; i < limit; i++)
            {
                // Console.WriteLine("Counter to be taken (Make Move): " + counterToBeTaken[i, 0] + " " + counterToBeTaken[i, 1]);
                if (x == destinationAfterTake[i, 0] && y == destinationAfterTake[i, 1])
                {
                    bxArray[counterToBeTaken[i, 0], counterToBeTaken[i, 1]].populated = false;
                    bxArray[counterToBeTaken[i, 0], counterToBeTaken[i, 1]].populatedBy = "";
                    bxArray[counterToBeTaken[i, 0], counterToBeTaken[i, 1]].king = false;
                    DecreaseCounterCount();
                    taken = true;
                    break;
                }
            }
            
            if (i == limit)
            {
                taken = false;
            }
            

            Array.Clear(destinationAfterTake, 0, destinationAfterTake.Length);
            Array.Clear(counterToBeTaken, 0, counterToBeTaken.Length);

            if (taken == false)
            {
                ChangeTurn();
            }

            // CheckAllMoves(x, y);
        }

        public void DecreaseCounterCount()
        {
            if (colourOfTurn == "B")
            {
                counterCountWhite -= 1;
            }
            else
            {
                counterCountBlack -= 1;
            }
        }

        public bool CheckCounterCount()
        {
            if (counterCountBlack > 0 && counterCountWhite > 0)
            {
                return true;
            }
            else if(counterCountWhite == 0)
            {
                Console.WriteLine("White wins!");
                return false;
            }
            else
            {
                Console.WriteLine("Black wins!");
                return false;
            }
        }

        public void ChangeTurn()
        {
            if (colourOfTurn == "B")
            {
                colourOfTurn = "W";
            }
            else
            {
                colourOfTurn = "B";
            }
        }
    }

    public struct Box
    {
        public bool populated;
        public string colour;       // The colour of the box
        public string populatedBy;  // The colour of the checker that is occupying the box 
        public bool king;
    }
}