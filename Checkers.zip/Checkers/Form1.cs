﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Checkers
{
    public partial class Board : Form
    {
        private string colourOfTurn = "W";
        private int[] previouslyClicked = new int[2];
        Button[,] btn = new Button[8, 8];      // Create 2D array of buttons
        Box[,] bxArray = new Box[8, 8];
        private int[,] destinationAfterTake = new int[2, 2];
        private int[,] counterToBeTaken = new int[2, 2];
        public Board()
        {
            InitializeComponent();
            bool whiteSquare = true; 
            for (int x = 0; x < btn.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < btn.GetLength(1); y++)     // Loop for y
                {
                    btn[x, y] = new Button();
                    btn[x, y].SetBounds(100 * x, 100 * y, 100, 100);
                    if (whiteSquare == false)
                    {
                        if (y < 3)
                        {
                            bxArray[x, y].populated = true;
                            bxArray[x, y].populatedBy = "W";     // W for white
                            //btn[x, y].Image = Image.FromFile("Annotation 2020-02-06 163221.png");
                            Console.WriteLine(x + " " + y + "is populated by white");
                        }
                        else if (y > 4)
                        {
                            bxArray[x, y].populated = true;
                            bxArray[x, y].populatedBy = "B";     // B for black
                            //btn[x, y].Image = Image.FromFile("Annotation 2020-02-06 163222.png");
                            Console.WriteLine(x + " " + y + "is populated by black");
                        }
                    }
                    if (whiteSquare == true)
                    {
                        btn[x, y].BackColor = Color.White;
                        bxArray[x, y].colour = "W";
                        whiteSquare = false;
                    }
                    else
                    {
                        btn[x, y].BackColor = Color.Black;
                        btn[x, y].ForeColor = Color.White;
                        bxArray[x, y].colour = "B";
                        whiteSquare = true;
                    }
                    btn[x, y].Name = Convert.ToString(x + "," + y + bxArray[x,y].populatedBy);
                    btn[x, y].Text = bxArray[x, y].populatedBy;
                    btn[x, y].Click += new EventHandler(this.btnEvent_Click);
                    Controls.Add(btn[x, y]);
                    
                }
                if (whiteSquare == true)
                {
                    whiteSquare = false;
                }
                else
                {
                    whiteSquare = true;
                }
            }
        }

        void btnEvent_Click(object sender, EventArgs e)
        {
            int x = int.Parse(((Button)sender).Name[0].ToString());
            int y = int.Parse(((Button)sender).Name[2].ToString());

            /*
            Console.WriteLine(((Button)sender).Text);    // SAME handler as before
            Console.WriteLine(((Button)sender).Text[0] + " " + ((Button)sender).Text[2]);
            */

            if(((Button)sender).BackColor == Color.Blue)
            {
                MakeMove(previouslyClicked[0], previouslyClicked[1], x, y);
                RefreshBoard();
            }
            /*
            else if(((Button)sender).BackColor == Color.DarkBlue)
            {
                MakeMove(previouslyClicked[0], previouslyClicked[1], x, y);
                TakeCounter();
                RefreshBoard();
            }
            */
            else if(bxArray[x,y].populatedBy == colourOfTurn)
            {
                RefreshBoard();
                CheckAllMoves(x, y);
                previouslyClicked[0] = x;
                previouslyClicked[1] = y;
            }
        }

        /*
        private void button1_Click(object sender, EventArgs e)
        {

        }
        */

        public void CheckAllMoves(int x, int y)
        {
            if (bxArray[x, y].populatedBy == colourOfTurn)
            {
                int[,] arrayOfMoves = new int[2, 2];
                if (colourOfTurn == "B")
                {
                    // the block diagonally to the left
                    arrayOfMoves[0, 0] = x - 1;
                    arrayOfMoves[0, 1] = y - 1;
                    // the block diagonally to the right
                    arrayOfMoves[1, 0] = x + 1;
                    arrayOfMoves[1, 1] = y - 1;
                }
                else
                {
                    // the block diagonally to the left
                    arrayOfMoves[0, 0] = x - 1;
                    arrayOfMoves[0, 1] = y + 1;
                    // the block diagonally to the right
                    arrayOfMoves[1, 0] = x + 1;
                    arrayOfMoves[1, 1] = y + 1;
                }
                for (int i = 0; i < 2; i++)
                {
                    // Checking that the square that we are testing is in range of the table, otherwise skip this square
                    if (arrayOfMoves[i, 0] < 0 || arrayOfMoves[i, 1] < 0 || arrayOfMoves[i, 0] > 7 || arrayOfMoves[i, 1] > 7)
                    {
                        continue;
                    }
                    // if there are no valid moves
                    if (CheckMove(arrayOfMoves[i, 0], arrayOfMoves[i, 1]) == "N")
                    {
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                    }
                    // if there is a valid move where one of the opposing players counters could be taken
                    else if (CheckMove(arrayOfMoves[i, 0], arrayOfMoves[i, 1]) == "T")
                    {
                        // needs to be a link to the new function here
                        Console.WriteLine("Take Available");
                        CheckMoveWithTake(arrayOfMoves[i, 0], arrayOfMoves[i, 1], i, arrayOfMoves);
                    }
                    // if there is just a straight-forward move
                    else if (CheckMove(arrayOfMoves[i, 0], arrayOfMoves[i, 1]) == "Y")
                    {
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Blue;
                    }
                }
            }
            else
            {
                return;
            }
        }

        public void CheckMoveWithTake(int x, int y, int i , int [,] arrayOfMoves)
        {
            // if it is checking to the left
            int[] boxToCheck = new int[2];
            try
            {
                if (i == 0)
                {
                    if (colourOfTurn == "B")
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] - 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] - 1;
                        // if (arrayOfMoves[i, 0] > 0 && arrayOfMoves[i, 1] > 0) { btn[arrayOfMoves[i, 0] - 1, arrayOfMoves[i, 1] - 1].BackColor = Color.Blue; }
                    }
                    else
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] - 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] + 1;
                        // if (arrayOfMoves[i, 0] > 0 && arrayOfMoves[i, 1] < 7) { btn[arrayOfMoves[i, 0] - 1, arrayOfMoves[i, 1] + 1].BackColor = Color.Blue; }
                    }
                }
                // if it is checking to the right
                else
                {
                    if (colourOfTurn == "B")
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] + 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] - 1;
                        // if (arrayOfMoves[i, 0] < 7 && arrayOfMoves[i, 1] > 0) { btn[arrayOfMoves[i, 0] + 1, arrayOfMoves[i, 1] - 1].BackColor = Color.Blue; }
                    }
                    else
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] + 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] + 1;
                        // if (arrayOfMoves[i, 0] < 7 && arrayOfMoves[i, 1] < 7) { btn[arrayOfMoves[i, 0] + 1, arrayOfMoves[i, 1] + 1].BackColor = Color.Blue; }
                    }
                }
                Console.WriteLine("Box to check: " + boxToCheck[0] + boxToCheck[1]);
                if (boxToCheck[0] >= 0 && boxToCheck[0] < 8 && boxToCheck[1] >= 0 && boxToCheck[1] < 8)
                {
                    if (bxArray[boxToCheck[0], boxToCheck[1]].populated == true)
                    {
                        btn[arrayOfMoves[i,0], arrayOfMoves[i,1]].BackColor = Color.Red;
                        Console.WriteLine("Box is populated");
                        return;
                    }
                    else
                    {
                        destinationAfterTake[i, 0] = boxToCheck[0];
                        destinationAfterTake[i, 1] = boxToCheck[1];
                        counterToBeTaken[i, 0] = arrayOfMoves[i, 0];
                        counterToBeTaken[i, 1] = arrayOfMoves[i, 1];

                        btn[boxToCheck[0], boxToCheck[1]].BackColor = Color.Blue;
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Orange;
                    }
                }
                else
                {
                    btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                    return;
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e + "Error in the method: CheckMoveWithTake");
                return;
            }
        }

        public string CheckMove(int x, int y)
        {
            try
            {
                if (bxArray[x, y].populatedBy == colourOfTurn)
                {
                    return "N";
                }
                else if (bxArray[x, y].populated == true)
                {
                    // "T" for take (if it is populated and the colour is not the same as the colour of the player)
                    Console.WriteLine("Take Available");
                    return "T";
                }
                else
                {
                    return "Y";
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e + "Error in the method: CheckMove");
                return "E";
            }
        }

        public void TakeCounter()
        {
            for (int x = 0; x < bxArray.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < bxArray.GetLength(1); y++)     // Loop for y
                {
                    if (btn[x, y].BackColor == Color.Orange)
                    {
                        bxArray[x, y].populated = false;
                        bxArray[x, y].populatedBy = "";
                    }       
                }
            }
        }

        public void RefreshBoard()
        {
            for (int x = 0; x < bxArray.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < bxArray.GetLength(1); y++)     // Loop for y
                {
                    // This is the bit that doesn't work
                    /*
                    if (btn[x, y].BackColor == Color.Orange)
                    {
                        bxArray[x, y].populated = false;
                        bxArray[x, y].populatedBy = "";
                    }
                    */
                    if (bxArray[x, y].colour == "W")
                    {
                        btn[x, y].BackColor = Color.White;
                    }
                    else
                    {
                        btn[x, y].BackColor = Color.Black;
                    }
                    btn[x, y].Name = Convert.ToString(x + "," + y + bxArray[x, y].populatedBy);
                    btn[x, y].Text = bxArray[x, y].populatedBy;
                }
            }
        }

        public void MakeMove(int ogX, int ogY, int x, int y)
        {
            if(btn[x,y].BackColor == Color.Blue)
            {
                bxArray[x, y].populatedBy = colourOfTurn;
                bxArray[x, y].populated = true;

                bxArray[ogX, ogY].populatedBy = "";
                bxArray[ogX, ogY].populated = false;
            }
            else
            {
                return;
            }

            for(int i = 0; i < 2; i++)
            {
                if(x == destinationAfterTake[i, 0]){
                    Console.WriteLine("Did this");
                    bxArray[counterToBeTaken[i, 0], counterToBeTaken[i, 1]].populated = false;
                    bxArray[counterToBeTaken[i, 0], counterToBeTaken[i, 1]].populatedBy = "";
                    
                }
            }

            if(colourOfTurn == "B")
            {
                colourOfTurn = "W";
            }
            else
            {
                colourOfTurn = "B";
            }
            CheckAllMoves(x, y);
        }
    }

    public struct Box
    {
        public bool populated;
        public string colour;       // The colour of the box
        public string populatedBy;  // The colour of the checker that is occupying the box 
    }
}