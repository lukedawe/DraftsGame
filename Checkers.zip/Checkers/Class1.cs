﻿using System;

public class Box
{
    public bool populated = false;
    public string colour = "white";
	public Box()
	{

	}
}
