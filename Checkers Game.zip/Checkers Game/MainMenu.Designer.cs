﻿namespace Checkers_Game
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.Start_Button = new System.Windows.Forms.Button();
            this.Settings_Button = new System.Windows.Forms.Button();
            this.Exit_Button = new System.Windows.Forms.Button();
            this.Credits_Button = new System.Windows.Forms.Button();
            this.Instruction_Button = new System.Windows.Forms.Button();
            this.LeaderBoard_Button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Start_Button
            // 
            this.Start_Button.BackColor = System.Drawing.Color.SeaGreen;
            this.Start_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Start_Button.Font = new System.Drawing.Font("Stencil", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Start_Button.ForeColor = System.Drawing.Color.DarkRed;
            this.Start_Button.Location = new System.Drawing.Point(269, 215);
            this.Start_Button.Name = "Start_Button";
            this.Start_Button.Size = new System.Drawing.Size(226, 32);
            this.Start_Button.TabIndex = 0;
            this.Start_Button.Text = "Start";
            this.Start_Button.UseVisualStyleBackColor = false;
            this.Start_Button.Click += new System.EventHandler(this.Start_Button_Click);
            // 
            // Settings_Button
            // 
            this.Settings_Button.BackColor = System.Drawing.Color.SeaGreen;
            this.Settings_Button.Cursor = System.Windows.Forms.Cursors.Default;
            this.Settings_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Settings_Button.Font = new System.Drawing.Font("Stencil", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Settings_Button.ForeColor = System.Drawing.Color.DarkRed;
            this.Settings_Button.Location = new System.Drawing.Point(269, 350);
            this.Settings_Button.Name = "Settings_Button";
            this.Settings_Button.Size = new System.Drawing.Size(226, 32);
            this.Settings_Button.TabIndex = 1;
            this.Settings_Button.Text = "Settings";
            this.Settings_Button.UseVisualStyleBackColor = false;
            this.Settings_Button.Click += new System.EventHandler(this.Settings_Button_Click);
            // 
            // Exit_Button
            // 
            this.Exit_Button.BackColor = System.Drawing.Color.SeaGreen;
            this.Exit_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Exit_Button.Font = new System.Drawing.Font("Stencil", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit_Button.ForeColor = System.Drawing.Color.DarkRed;
            this.Exit_Button.Location = new System.Drawing.Point(332, 440);
            this.Exit_Button.Name = "Exit_Button";
            this.Exit_Button.Size = new System.Drawing.Size(99, 32);
            this.Exit_Button.TabIndex = 2;
            this.Exit_Button.Text = "Exit";
            this.Exit_Button.UseVisualStyleBackColor = false;
            this.Exit_Button.Click += new System.EventHandler(this.Exit_Button_Click);
            // 
            // Credits_Button
            // 
            this.Credits_Button.BackColor = System.Drawing.Color.SeaGreen;
            this.Credits_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Credits_Button.Font = new System.Drawing.Font("Stencil", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Credits_Button.ForeColor = System.Drawing.Color.DarkRed;
            this.Credits_Button.Location = new System.Drawing.Point(269, 395);
            this.Credits_Button.Name = "Credits_Button";
            this.Credits_Button.Size = new System.Drawing.Size(226, 32);
            this.Credits_Button.TabIndex = 3;
            this.Credits_Button.Text = "Credits";
            this.Credits_Button.UseVisualStyleBackColor = false;
            this.Credits_Button.Click += new System.EventHandler(this.Credits_Button_Click);
            // 
            // Instruction_Button
            // 
            this.Instruction_Button.BackColor = System.Drawing.Color.SeaGreen;
            this.Instruction_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Instruction_Button.Font = new System.Drawing.Font("Stencil", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Instruction_Button.ForeColor = System.Drawing.Color.DarkRed;
            this.Instruction_Button.Location = new System.Drawing.Point(269, 260);
            this.Instruction_Button.Name = "Instruction_Button";
            this.Instruction_Button.Size = new System.Drawing.Size(226, 32);
            this.Instruction_Button.TabIndex = 4;
            this.Instruction_Button.Text = "How To Play";
            this.Instruction_Button.UseVisualStyleBackColor = false;
            this.Instruction_Button.Click += new System.EventHandler(this.Instruction_Button_Click);
            // 
            // LeaderBoard_Button
            // 
            this.LeaderBoard_Button.BackColor = System.Drawing.Color.SeaGreen;
            this.LeaderBoard_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LeaderBoard_Button.Font = new System.Drawing.Font("Stencil", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeaderBoard_Button.ForeColor = System.Drawing.Color.DarkRed;
            this.LeaderBoard_Button.Location = new System.Drawing.Point(269, 305);
            this.LeaderBoard_Button.Name = "LeaderBoard_Button";
            this.LeaderBoard_Button.Size = new System.Drawing.Size(226, 32);
            this.LeaderBoard_Button.TabIndex = 5;
            this.LeaderBoard_Button.Text = "LeaderBoard";
            this.LeaderBoard_Button.UseVisualStyleBackColor = false;
            this.LeaderBoard_Button.Click += new System.EventHandler(this.LeaderBoard_Button_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::Checkers_Game.Properties.Resources.Cool_Text___Checkers_Game_349091277747211;
            this.pictureBox1.Location = new System.Drawing.Point(33, 71);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(701, 98);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(606, 291);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::Checkers_Game.Properties.Resources.Background;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.LeaderBoard_Button);
            this.Controls.Add(this.Instruction_Button);
            this.Controls.Add(this.Credits_Button);
            this.Controls.Add(this.Exit_Button);
            this.Controls.Add(this.Settings_Button);
            this.Controls.Add(this.Start_Button);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 600);
            this.Name = "MainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Checkers Game";
            this.Load += new System.EventHandler(this.MainMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Start_Button;
        private System.Windows.Forms.Button Settings_Button;
        private System.Windows.Forms.Button Exit_Button;
        private System.Windows.Forms.Button Credits_Button;
        private System.Windows.Forms.Button Instruction_Button;
        private System.Windows.Forms.Button LeaderBoard_Button;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
    }
}

