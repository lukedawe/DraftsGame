﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using Checkers;

namespace Checkers_Game
{
    public partial class MainMenu : Form
    {
        SoundPlayer buttonClick = new SoundPlayer("button.wav");
        public MainMenu()
        {
            InitializeComponent();
        }

        private void Start_Button_Click(object sender, EventArgs e)
        {
            // Opens new form and closes current
            buttonClick.Play();
            this.Hide();
            Board settingForm = new Board();
            settingForm.ShowDialog();

            this.Close();
        }

        private void Exit_Button_Click(object sender, EventArgs e)
        {
            buttonClick.Play();

            Application.Exit();
        }

        private void Settings_Button_Click(object sender, EventArgs e)
        {
            // Opens new form and closes current
            buttonClick.Play();
            this.Hide();
            Settings settingForm = new Settings();
            settingForm.ShowDialog();
            this.Close();
        }

        private void Instruction_Button_Click(object sender, EventArgs e)
        {
            // Opens new form and closes current
            buttonClick.Play();
            this.Hide();
            Instructions instructionsForm = new Instructions();
            instructionsForm.ShowDialog();
            this.Close();
        }

        private void Credits_Button_Click(object sender, EventArgs e)
        {
            // Opens new form and closes current
            buttonClick.Play();
            this.Hide();
            Credits creditsForm = new Credits();
            creditsForm.ShowDialog();
           
        }

        private void LeaderBoard_Button_Click(object sender, EventArgs e)
        {
            // Opens new form and closes current
            buttonClick.Play();

            this.Hide();
            LeaderBoard leaderBoardForm = new LeaderBoard();
            leaderBoardForm.ShowDialog();
            this.Close();
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            InputBox g = new InputBox();

            g.ShowDialog();
        }
    }
}
