﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Checkers_Game
{

    public partial class Credits : Form
    {
        public Credits()
        {
            InitializeComponent();
        }
        SoundPlayer back = new SoundPlayer("back.wav");
        private void Back_Button_Click(object sender, EventArgs e)
        {
            back.Play();
            // Opens new form and closes current
            this.Hide();
            MainMenu MainMenuForm = new MainMenu();
            MainMenuForm.ShowDialog();
            this.Close();
        }
    }
}
