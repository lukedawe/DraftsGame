﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Media;

namespace Checkers_Game
{
    public partial class LeaderBoard : Form
    {
        String[] n;
        SoundPlayer buttonClick = new SoundPlayer("button.wav");

        public LeaderBoard()
        {
            InitializeComponent();
        }
        
        private void Back_Button_Click(object sender, EventArgs e)
        {
            // Opens new form and closes current
            buttonClick.Play();
            this.Hide();
            MainMenu MainMenuForm = new MainMenu();
            MainMenuForm.ShowDialog();
            this.Close();

        }
        
        private void LeaderBoard_Load(object sender, EventArgs e)
        {
            Alphabetical_Click(sender,  e);
        }
    
        private void Alphabetical_Click(object sender, EventArgs e)
        {
            // Init reader
            LeaderboardText.Clear();
            string location = "test.txt";
            List<String> noSortScore = new List<String>();

            if (File.Exists(location))
            {
                StreamReader reader = new StreamReader(location);
                // Starts from the beginning of rfile 
                reader.BaseStream.Seek(0, SeekOrigin.Begin);
                string text = reader.ReadLine();
                // Reads every line until it hits null
                while (text != null)
                {
                    noSortScore.Add(text);
                    text = reader.ReadLine();
                }
                // close
                reader.Close();
            }


            else
            {

                MessageBox.Show("Mate big problem Can't find the leaderboard what have you done");

            }
            String[] n = noSortScore.ToArray();
            Console.WriteLine(n[1]);
            Array.Sort(n);

            for (int i = 0; i != n.Length; i++)
            {
                LeaderboardText.AppendText(n[i]);
                LeaderboardText.AppendText(Environment.NewLine);
                LeaderboardText.AppendText(Environment.NewLine);
            }
           

        }

        private void Wins_Click(object sender, EventArgs e)
        {
            LeaderboardText.Clear();

            string[] temp;

            string location = "test.txt";
            List<String> noSortScore = new List<String>();

            if (File.Exists(location))
            {
                StreamReader reader = new StreamReader(location);
                // Starts from the beginning of rfile 
                reader.BaseStream.Seek(0, SeekOrigin.Begin);
                string text = reader.ReadLine();


                // Reads every line until it hits null
                while (text != null)
                {
                    temp = text.Split(' ');

                    noSortScore.Add(temp[0]);
                    noSortScore.Add(temp[1]);
                    text = reader.ReadLine();
                }
                // close
                reader.Close();
            }


            else
            {

                MessageBox.Show("Mate big problem Can't find the leaderboard what have you done");

            }

            // Got Bubble sort online but adapted it to this
            String[] wins = noSortScore.ToArray();
            String temp2;
            int temp3 =0;
            int temp4  =0;
            
            for (int j = 1; j <= wins.Length - 2; j++)
            {
                for (int i = 1; i <= wins.Length - 2; i= i+2)
                {
                    temp3 = int.Parse(wins[i]);
                    temp4 = int.Parse(wins[i + 2]);
                    if (temp3 < temp4)
                    {
                        temp2 = wins[i];
                        wins[i +2] = wins[i];
                        wins[i] = temp2;
                    }
                }
            }

            Console.Write(wins[3]);
            Console.Write("GGGGGGGGG");
            for (int i = 0; i != wins.Length; i= i+2)
            {
                LeaderboardText.AppendText(wins[i] + " "+ wins[i+1]);
                LeaderboardText.AppendText(Environment.NewLine);
                LeaderboardText.AppendText(Environment.NewLine);
            }

        }

        private void LeaderboardText_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
