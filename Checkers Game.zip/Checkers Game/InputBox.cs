﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Checkers_Game
{
    public partial class InputBox : Checkers_Game.Settings
    {
        public InputBox()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Enter.Enabled = true;
        }

        private void Enter_Click(object sender, EventArgs e)
        {
            Boolean found = false;
            string[] temp;
            int temp2;
            string userName = textBox1.Text;

            string location = "test.txt";
            List<String> names = new List<String>();

            if (File.Exists(location))
            {
                StreamReader reader = new StreamReader(location);
                // Starts from the beginning of rfile 
                reader.BaseStream.Seek(0, SeekOrigin.Begin);
                string text = reader.ReadLine();

                // Reads every line until it hits null
                while (text != null)
                {
                    temp = text.Split(' ');
                    names.Add(temp[0]);
                    names.Add(temp[1]);
                    text = reader.ReadLine();
                }
                // close
                reader.Close();
            }
            else
            {
                MessageBox.Show("Mate big problem Can't find the leaderboard what have you done");
            }

            for(int i= 0; i!= names.Count; i = i+2)
            {
                if(names[i] == userName)
                {
                  temp2 =  int.Parse(names[i + 1]) + 1;
                    names[i + 1] = temp2.ToString();
                    found = true;
                }
            }
            
            if(found == false)
            {
                names.Add(userName);
                names.Add("1");
            }

                StreamWriter writer = new StreamWriter("test.txt");
                for (int i = 0; i != names.Count; i=i+2)
                {
                    writer.WriteLine(names[i] +" "+names[i+1]);
                }
         
                writer.Close();
            MessageBox.Show("well Done");

            this.Close();
            

        }
    }
}
