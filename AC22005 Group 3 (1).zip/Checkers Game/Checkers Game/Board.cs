﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Checkers;
using Checkers_Game;


namespace Checkers
{
    public partial class Board : Form
    {

        private int counterCountWhite = 12;
        private int counterCountBlack = 12;
        private string colourOfTurn = "W";
        private int[] previouslyClicked = new int[2];
        Button[,] btn = new Button[8, 8];      // Create 2D array of buttons
        Box[,] bxArray = new Box[8, 8];         // Make a 2D array of boxes, this will act as the board behind the scenes
        private int[,] destinationAfterTake = new int[4, 2];    // This is the destination of the box before the counter has moved
        private int[,] counterToBeTaken = new int[4, 2];        // This is the coordinates of the counter that the counter is taking
        private bool taken = false;     // Stores whether the player took a counter last turn, required for double moving
        private bool king;              // Stores whether the player has selected a king piece
        public int turnTimer = 20;


        public Board()
        {
            InitializeComponent();
            Turn.Text = "White's Turn";
            WCounter.Text = counterCountWhite.ToString();
            BCounter.Text = counterCountBlack.ToString();
            bool whiteSquare = true;

            for (int x = 0; x < btn.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < btn.GetLength(1); y++)     // Loop for y
                {
                    btn[x, y] = new Button();
                    btn[x, y].SetBounds(100 * x, 100 * y + 24, 100, 100);    // Sets the button size
                    btn[x, y].Font = new Font(btn[x, y].Font.FontFamily, 22);
                    if (whiteSquare == false)
                    {
                        if (y < 3)
                        {
                            bxArray[x, y].populated = true;
                            bxArray[x, y].populatedBy = "W";     // W for white
                       
                            // btn[x, y].Image = Image.FromFile("abc.PNG");
                        }
                        else if (y > 4)
                        {
                            bxArray[x, y].populated = true;
                            bxArray[x, y].populatedBy = "B";     // B for black
                               

                        }
                    }
                    if (whiteSquare == true)
                    {
                        btn[x, y].BackColor = Color.White;
                        bxArray[x, y].colour = "W";

                        whiteSquare = false;
                    }
                    else
                    {
                        btn[x, y].BackColor = Color.Black;
                        btn[x, y].ForeColor = Color.White;
                        bxArray[x, y].colour = "B";

                        whiteSquare = true;
                    }

                    btn[x, y].Name = Convert.ToString(x + "," + y + bxArray[x, y].populatedBy);

                    btn[x, y].Text = bxArray[x, y].populatedBy;

                    btn[x, y].Click += new EventHandler(this.btnEvent_Click);
                    Controls.Add(btn[x, y]);

                }
                if (whiteSquare == true)
                {
                    whiteSquare = false;
                }
                else
                {
                    whiteSquare = true;
                }
            }
        }

        // A method to reset the board when the player chooses to play the game again
        public void ResetBoard()
        {
            for (int x = 0; x < btn.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < btn.GetLength(1); y++)     // Loop for y
                {
                    bxArray[x, y].populated = false;
                    bxArray[x, y].populatedBy = "";
                    if (btn[x, y].BackColor == Color.Black)
                    {
                        if (y < 3)
                        {
                            bxArray[x, y].populated = true;
                            bxArray[x, y].populatedBy = "W";     // W for white
                                                                 //btn[x, y].Image = Image.FromFile("abc.JPG");
                        }
                        else if (y > 4)
                        {
                            bxArray[x, y].populated = true;
                            bxArray[x, y].populatedBy = "B";     // B for black                                   
                        }
                    }
                }
            }
            // Set the counter counts back to normal
            counterCountBlack = 12;
            counterCountWhite = 12;
            BCounter.Text = "12";
            BCounter.Text = "12";
            // Reset the timer
            timer1.Enabled = true;
            turnTimer = 20;
            colourOfTurn = "W";
            Turn.Text = "White's Turn";
            RefreshBoard();
        }

        private void btnEvent_Paint(object sender, PaintEventArgs e)
        {
            Bitmap bmp = Checkers_Game.Properties.Resources.Back_Arrow;
            bmp.MakeTransparent(Color.White);
            int x = (((Button)sender).Width - bmp.Width) / 2;
            int y = (((Button)sender).Height - bmp.Height) / 2;
            e.Graphics.DrawImage(bmp, x, y);
        }


        // Method for when the mouse is clicked
        void btnEvent_Click(object sender, EventArgs e)
        {
            Console.WriteLine("============================");
            // Get the x and they for the click
            int x = int.Parse(((Button)sender).Name[0].ToString());
            int y = int.Parse(((Button)sender).Name[2].ToString());
            Console.WriteLine("Taken is: " + taken);
            // Read whether the player clicked on a king
            king = bxArray[x, y].king;
            Console.WriteLine("King is: " + king);
            // If the player clicks on a blue square
            if (((Button)sender).BackColor == Color.Blue)
            {
                MakeMove(previouslyClicked[0], previouslyClicked[1], x, y, king);
                // If the player did not take a counter last turn
                if (taken == false)
                {
                    RefreshBoard();
                }
                // If the player did take a counter in the last turn
                else
                {
                    // If the player did take a counter last turn
                    previouslyClicked[0] = x;
                    previouslyClicked[1] = y;
                    king = bxArray[previouslyClicked[0], previouslyClicked[1]].king;

                    // Refresh the board and check all the moves
                    RefreshBoard();
                    CheckAllMoves(x, y, king);
                }
            }
            // if the player did not click a blue square
            else if (bxArray[x, y].populatedBy == colourOfTurn && taken == false)
            {
                RefreshBoard();
                CheckAllMoves(x, y, king);
                previouslyClicked[0] = x;
                previouslyClicked[1] = y;
            }
            if (CheckCounterCount() == false)
            {
                this.Close();
            }
        }

        // Gets coordinates and checks the moves that are available for a counter of a given colour from that square
        public void CheckAllMoves(int x, int y, bool king = false)
        {
            bool validMove = false;
            int limit = 2;
            // If the player is using a king, the player has 4 possibilities for moves
            if (king == true)
            {
                limit = 4;
            }
            int[,] arrayOfMoves = new int[limit, 2];
            if (king == false)
            {
                if (colourOfTurn == "B")
                {
                    // the block diagonally to the left
                    arrayOfMoves[0, 0] = x - 1;
                    arrayOfMoves[0, 1] = y - 1;
                    // the block diagonally to the right
                    arrayOfMoves[1, 0] = x + 1;
                    arrayOfMoves[1, 1] = y - 1;
                }
                else
                {
                    // the block diagonally to the left
                    arrayOfMoves[0, 0] = x - 1;
                    arrayOfMoves[0, 1] = y + 1;
                    // the block diagonally to the right
                    arrayOfMoves[1, 0] = x + 1;
                    arrayOfMoves[1, 1] = y + 1;
                }
            }
            else
            {
                // the block diagonally to the left
                arrayOfMoves[0, 0] = x - 1;
                arrayOfMoves[0, 1] = y - 1;
                // the block diagonally to the right
                arrayOfMoves[1, 0] = x + 1;
                arrayOfMoves[1, 1] = y - 1;

                // the block diagonally to the left
                arrayOfMoves[2, 0] = x - 1;
                arrayOfMoves[2, 1] = y + 1;
                // the block diagonally to the right
                arrayOfMoves[3, 0] = x + 1;
                arrayOfMoves[3, 1] = y + 1;
            }
            // This doesn't matter for the king
            for (int i = 0; i < limit; i++)
            {
                // Checking that the square that we are testing is in range of the table, otherwise skip this square
                if (arrayOfMoves[i, 0] < 0 || arrayOfMoves[i, 1] < 0 || arrayOfMoves[i, 0] > 7 || arrayOfMoves[i, 1] > 7)
                {
                    continue;
                }
                // if there are no valid moves
                if (CheckMove(arrayOfMoves[i, 0], arrayOfMoves[i, 1]) == "N")
                {
                    Console.WriteLine("No move");
                    btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                }
                // if there is a valid move where one of the opposing players counters could be taken
                else if (CheckMove(arrayOfMoves[i, 0], arrayOfMoves[i, 1]) == "T")
                {
                    if (king == true)
                    {
                        Console.WriteLine("King is true, searching for moves with take");
                        if (validMove == false)
                        {
                            validMove = CheckMoveWithTakeKing(arrayOfMoves[i, 0], arrayOfMoves[i, 1], i, arrayOfMoves);
                        }
                        else
                        {
                            CheckMoveWithTakeKing(arrayOfMoves[i, 0], arrayOfMoves[i, 1], i, arrayOfMoves);
                        }
                    }
                    else
                    {
                        // The king is always going to be false here
                        Console.WriteLine("Running check move with take");
                        if (validMove == false)
                        {
                            validMove = CheckMoveWithTake(arrayOfMoves[i, 0], arrayOfMoves[i, 1], i, arrayOfMoves);
                        }
                        else
                        {
                            CheckMoveWithTake(arrayOfMoves[i, 0], arrayOfMoves[i, 1], i, arrayOfMoves);
                        }
                    }
                }
                // if there is just a straight-forward move
                else if (CheckMove(arrayOfMoves[i, 0], arrayOfMoves[i, 1]) == "Y")
                {
                    // validMove = true;
                    Console.WriteLine("Move available");
                    btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Blue;
                }
            }
            Console.WriteLine("if statement: valid move is: " + validMove + " and taken is: " + taken);
            if (validMove == false && taken == true)
            {
                ChangeTurn();
                RefreshBoard();
                taken = false;
            }
        }

        public bool CheckMoveWithTakeKing(int x, int y, int i, int[,] arrayOfMoves)
        {
            int[] boxToCheck = new int[2];
            // 4 for each possible moves
            try
            {
                if (i == 0)
                {
                    boxToCheck[0] = arrayOfMoves[i, 0] - 1;
                    boxToCheck[1] = arrayOfMoves[i, 1] - 1;
                }
                else if (i == 1)
                {
                    boxToCheck[0] = arrayOfMoves[i, 0] + 1;
                    boxToCheck[1] = arrayOfMoves[i, 1] - 1;
                }
                else if (i == 2)
                {
                    boxToCheck[0] = arrayOfMoves[i, 0] - 1;
                    boxToCheck[1] = arrayOfMoves[i, 1] + 1;
                }
                else if (i == 3)
                {
                    boxToCheck[0] = arrayOfMoves[i, 0] + 1;
                    boxToCheck[1] = arrayOfMoves[i, 1] + 1;
                }
                // if the box check is within the limits of the board
                if (boxToCheck[0] >= 0 && boxToCheck[0] < 8 && boxToCheck[1] >= 0 && boxToCheck[1] < 8)
                {
                    // If the box that the counter has to move to is taken, make the box red
                    if (bxArray[boxToCheck[0], boxToCheck[1]].populated == true)
                    {
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                        return false;
                    }
                    // Otherwise there is definitely a possible move
                    else
                    {
                        destinationAfterTake[i, 0] = boxToCheck[0];
                        destinationAfterTake[i, 1] = boxToCheck[1];
                        counterToBeTaken[i, 0] = arrayOfMoves[i, 0];
                        counterToBeTaken[i, 1] = arrayOfMoves[i, 1];

                        btn[boxToCheck[0], boxToCheck[1]].BackColor = Color.Blue;
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Orange;
                        return true;
                    }
                }
                else
                {
                    btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                    return false;
                }
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool CheckMoveWithTake(int x, int y, int i, int[,] arrayOfMoves)
        {
            // if it is checking to the left
            int[] boxToCheck = new int[2];
            try
            {
                if (i == 0)
                {
                    if (colourOfTurn == "B")
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] - 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] - 1;
                    }
                    else
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] - 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] + 1;
                    }
                }
                // if it is checking to the right
                else
                {
                    if (colourOfTurn == "B")
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] + 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] - 1;
                    }
                    else
                    {
                        boxToCheck[0] = arrayOfMoves[i, 0] + 1;
                        boxToCheck[1] = arrayOfMoves[i, 1] + 1;
                    }
                }
                // if the box check is within the limits of the board
                if (boxToCheck[0] >= 0 && boxToCheck[0] < 8 && boxToCheck[1] >= 0 && boxToCheck[1] < 8)
                {
                    if (bxArray[boxToCheck[0], boxToCheck[1]].populated == true)
                    {
                        Console.WriteLine("Box is populated: " + boxToCheck[0] + " " + boxToCheck[1]);
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                        return false;
                    }
                    else
                    {
                        // Otherwise there is definitely a possible move
                        Console.WriteLine("Box is not populated, move is available: " + boxToCheck[0] + " " + boxToCheck[1]);
                        destinationAfterTake[i, 0] = boxToCheck[0];
                        destinationAfterTake[i, 1] = boxToCheck[1];
                        counterToBeTaken[i, 0] = arrayOfMoves[i, 0];
                        counterToBeTaken[i, 1] = arrayOfMoves[i, 1];

                        btn[boxToCheck[0], boxToCheck[1]].BackColor = Color.Blue;
                        btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Orange;
                        return true;
                    }
                }
                else
                {
                    btn[arrayOfMoves[i, 0], arrayOfMoves[i, 1]].BackColor = Color.Red;
                    return false;
                }
            }
            catch (Exception e)
            {
                return false;
            }
        }

        // checks if there is a possibility of a move
        public string CheckMove(int x, int y)
        {
            try
            {
                // Not a move
                if (bxArray[x, y].populatedBy == colourOfTurn)
                {
                    return "N";
                }
                else if (bxArray[x, y].populated == true)
                {
                    // "T" for take (if it is populated and the colour is not the same as the colour of the player)
                    return "T";
                }
                else
                {
                    return "Y";
                }
            }
            catch (Exception e)
            {
                return "E";
            }
        }

        // Refreshes the board
        public void RefreshBoard()
        {

            for (int x = 0; x < bxArray.GetLength(0); x++)         // Loop for x
            {
                for (int y = 0; y < bxArray.GetLength(1); y++)     // Loop for y
                {
                    if (bxArray[x, y].colour == "W")
                    {
                        // set the colour to white
                        btn[x, y].BackColor = Color.White;
                        btn[x, y].Image = null;

                    }
                    else
                    {
                        btn[x, y].BackColor = Color.Black;
                    }
                    btn[x, y].Name = Convert.ToString(x + "," + y + bxArray[x, y].populatedBy);
                    btn[x, y].Text = bxArray[x, y].populatedBy;
                }
            }
        }

        // Used for swapping a counter and a blank space
        public void SwapPositions(int ogX, int ogY, int x, int y)
        {
            string tempPopulatedBy = bxArray[x, y].populatedBy;
            bool tempPopulated = bxArray[x, y].populated;
            bool tempKing = bxArray[x, y].king;
            Color tempColour = btn[x, y].ForeColor;

            bxArray[x, y].populatedBy = bxArray[ogX, ogY].populatedBy;
            bxArray[x, y].populated = bxArray[ogX, ogY].populated;
            bxArray[x, y].king = bxArray[ogX, ogY].king;
            btn[x, y].ForeColor = btn[ogX, ogY].ForeColor;

            bxArray[ogX, ogY].populatedBy = tempPopulatedBy;
            bxArray[ogX, ogY].populated = tempPopulated;
            bxArray[ogX, ogY].king = tempKing;
            btn[ogX, ogY].ForeColor = tempColour;
        }

        public void MakeMove(int ogX, int ogY, int x, int y, bool king = false)
        {

            int limit = 4;

            if (king == true)
            {
                limit = 4;
            }

            if (btn[x, y].BackColor == Color.Blue)
            {
                // Move the counter
                SwapPositions(ogX, ogY, x, y);

                if (colourOfTurn == "B" && y == 0)
                {
                    bxArray[x, y].king = true;
                    btn[x, y].ForeColor = Color.Gold;
                }
                else if (colourOfTurn == "W" && y == 7)
                {
                    bxArray[x, y].king = true;
                    btn[x, y].ForeColor = Color.Gold;
                }
            }
            else
            {
                return;
            }

            int i = 0;
            for (i = 0; i < limit; i++)
            {
                // Console.WriteLine("Counter to be taken (Make Move): " + counterToBeTaken[i, 0] + " " + counterToBeTaken[i, 1]);
                if (x == destinationAfterTake[i, 0] && y == destinationAfterTake[i, 1])
                {
                    bxArray[counterToBeTaken[i, 0], counterToBeTaken[i, 1]].populated = false;
                    bxArray[counterToBeTaken[i, 0], counterToBeTaken[i, 1]].populatedBy = "";
                    bxArray[counterToBeTaken[i, 0], counterToBeTaken[i, 1]].king = false;
                    DecreaseCounterCount();
                    taken = true;
                    break;
                }
            }

            /*
            if (i == limit)
            {
                taken = false;
            }
            */


            Array.Clear(destinationAfterTake, 0, destinationAfterTake.Length);
            Array.Clear(counterToBeTaken, 0, counterToBeTaken.Length);

            if (taken == false)
            {
                ChangeTurn();
            }

            // CheckAllMoves(x, y);
        }

        public void DecreaseCounterCount()
        {
            if (colourOfTurn == "B")
            {

                counterCountWhite -= 1;
                WCounter.Text = counterCountWhite.ToString();
            }
            else
            {

                counterCountBlack -= 1;
                BCounter.Text = counterCountBlack.ToString();
            }
        }

        public bool CheckCounterCount()
        {
            if (counterCountBlack > 0 && counterCountWhite > 0)
            {
                return true;
            }
            else if (counterCountWhite == 0)
            {
                MessageBox.Show("Black wins!");
                UpdateLeaderBoard();



                Restart();
                return false;
            }
            else
            {
                MessageBox.Show("White wins!");
                UpdateLeaderBoard();
                Restart();
                return false;
            }
        }

        // To update the leaderboard
        public void UpdateLeaderBoard()
        {

            InputBox g = new InputBox();

            g.ShowDialog();

        }

        // To restart the game
        public void Restart()
        {
            DialogResult restart = MessageBox.Show("Would you like to play again ?", "Checkers Game", MessageBoxButtons.YesNo);
            if (restart == DialogResult.Yes)
            {
                ResetBoard();
            }
            else
            {
                this.Close();
                Main_Menu MainMenuForm = new Main_Menu();
                MainMenuForm.ShowDialog();
                this.Close();
            }
            
        }

        // Changes the turn
        public void ChangeTurn()
        {
            if (colourOfTurn == "B")
            {
                RefreshBoard();
                Turn.Text = "White's Turn";
                turnTimer = 20;
                Timer.Text = turnTimer.ToString();
                colourOfTurn = "W";
            }
            else
            {

                RefreshBoard();
                Turn.Text = "Black's Turn";
                turnTimer = 20;
                Timer.Text = turnTimer.ToString();
                colourOfTurn = "B";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            turnTimer--;
            Timer.Text = turnTimer.ToString();
            if (turnTimer == 0)
            {
                ChangeTurn();
                turnTimer = 20;
                Timer.Text = turnTimer.ToString();
            }
        }

        // Displays the timer
        private void Board_Load(object sender, EventArgs e)
        {
            Timer.Text = turnTimer.ToString();
        }

        // To end the game
        private void EndGame_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            if (colourOfTurn == "W")
            {
                counterCountWhite = 0;
            }
            else
            {
                counterCountBlack = 0;
            }
            CheckCounterCount();
        }

        private void RulesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1. Moves are allowed only on the dark squares, so pieces always move diagonally. Single pieces are always limited to forward moves toward the opponent\n   " +
               "2.A piece making a non - capturing move(not involving a jump) may move only one square   3.A piece making a capturing move(a jump) leaps over one of the opponent's pieces, landing in a straight diagonal line on the other side. Only one piece may be captured in a single jump; however, multiple jumps are allowed during a single turn \n " +
               "4.When a piece is captured, it is removed from the board 5. If a player is able to make a capture, there is no option; the jump must be made. If more than one capture is available, the player is free to choose whichever he or she prefers \n" +
               "6. When a piece reaches the furthest row from the player who controls that piece, it is crowned and becomes a king. One of the pieces which had been captured is placed on top of the king so that it is twice as high as a single piece\n " +
               "7. Kings are limited to moving diagonally but may move both forward and backward. (Remember that single pieces, i.e. non-kings, are always limited to forward move\n " +
               "8.Kings may combine jumps in several directions, forward and backward, on the same turn. Single pieces may shift direction diagonally during a multiple capture turn, but must always jump forward (toward the opponent)");


        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" This game was made in c# windows form by \n Jesse Chan, Luke Dawe and Lars Aarup ");
        }
    }

    public struct Box
    {
        public bool populated;
        public string colour;       // The colour of the box
        public string populatedBy;  // The colour of the checker that is occupying the box 
        public bool king;
    }
}