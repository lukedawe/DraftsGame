﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Media;

namespace Checkers_Game
{
    public partial class LeaderBoard : Form
    {
      
        SoundPlayer buttonClick = new SoundPlayer("button.wav");

        public LeaderBoard()
        {
            InitializeComponent();
        }
        
        private void Back_Button_Click(object sender, EventArgs e)
        {
            // Opens new form and closes current
            buttonClick.Play();
            this.Hide();
            Main_Menu MainMenuForm = new Main_Menu();
            MainMenuForm.ShowDialog();
            this.Close();

        }
        
        private void LeaderBoard_Load(object sender, EventArgs e)
        {
            Alphabetical_Click(sender,  e);
        }
    
        private void Alphabetical_Click(object sender, EventArgs e)
        {
            // Init reader
            LeaderboardText.Clear();
            string location = "test.txt";
            List<String> noSortScore = new List<String>();
            // checks if file exist
            if (File.Exists(location))
            {
                StreamReader reader = new StreamReader(location);
                // Starts from the beginning of rfile 
                reader.BaseStream.Seek(0, SeekOrigin.Begin);
                string text = reader.ReadLine();
                // Reads every line until it hits null
                while (text != null)
                {
                    noSortScore.Add(text);
                    text = reader.ReadLine();
                }
                // close
                reader.Close();
            }


            else
            {
                MessageBox.Show("Mate big problem Can't find the leaderboard what have you done");
            }
            // Puts list data into array and init
            String[] n = noSortScore.ToArray();
            Console.WriteLine(n[1]);
            Array.Sort(n);

            for (int i = 0; i != n.Length; i++)
            {
                // Apends text into textbox
                LeaderboardText.AppendText(n[i]);
                LeaderboardText.AppendText(Environment.NewLine);
                LeaderboardText.AppendText(Environment.NewLine);
            }
           

        }

        private void Wins_Click(object sender, EventArgs e)
        {
            // Clear text when button is pressed
            LeaderboardText.Clear();

            string[] temp = new string[2];

            string location = "test.txt";
            List<String> noSortScore = new List<String>();
            // Checks if file exist
            if (File.Exists(location))
            {
                StreamReader reader = new StreamReader(location);
                // Starts from the beginning of rfile 
                reader.BaseStream.Seek(0, SeekOrigin.Begin);
                string text = reader.ReadLine();


                // Reads every line until it hits null
                while (text != null)
                {
                    // splits text and adds to list
                    temp = text.Split(' ');

                    noSortScore.Add(temp[0]);
                    noSortScore.Add(temp[1]);
                    text = reader.ReadLine();
                }
                // close
                reader.Close();
            }


            else
            {

                MessageBox.Show("Mate big problem Can't find the leaderboard what have you done");

            }

            // Got Bubble sort online but adapted it to this
            String[] wins = noSortScore.ToArray();
            String temp2;
            int temp3 =0;
            int temp4  =0;
            
            // Checks every other data in array so it's just the number
            for (int j = 1; j <= wins.Length - 2; j= j+2)
            {
                for (int i = 1; i <= wins.Length - 2; i= i+2)
                {
                    // Changes data into numbers and stores it into temps
                    temp3 = int.Parse(wins[i]);
                    temp4 = int.Parse(wins[i + 2]);
                    // swaps
                    if (temp3 < temp4)
                    {
                        temp2 = wins[i];
                        wins[i] = wins[i+2];
                        wins[i+2] = temp2;
                    }
                }
            }
            // appends text
            for (int i = 0; i != wins.Length; i= i+2)
            {
                LeaderboardText.AppendText(wins[i] + " "+ wins[i+1]);
                LeaderboardText.AppendText(Environment.NewLine);
                LeaderboardText.AppendText(Environment.NewLine);
            }

        }

        private void LeaderboardText_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
