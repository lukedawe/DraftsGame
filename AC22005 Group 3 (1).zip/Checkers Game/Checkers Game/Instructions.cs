﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
namespace Checkers_Game
{
    public partial class Instructions : Form
    {
        SoundPlayer back = new SoundPlayer("back.wav");
        public Instructions()
        {
            InitializeComponent();
        }

        private void Back_Button_Click(object sender, EventArgs e)
        {
            // Opens new form and closes current
            back.Play();
            this.Hide();
            Main_Menu MainMenuForm = new Main_Menu();
            MainMenuForm.ShowDialog();
            this.Close();

        }
    }
}
