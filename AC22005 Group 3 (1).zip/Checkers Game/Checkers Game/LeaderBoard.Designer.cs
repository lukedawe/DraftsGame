﻿namespace Checkers_Game
{
    partial class LeaderBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LeaderBoard));
            this.Back_Button = new System.Windows.Forms.Button();
            this.Alphabetical = new System.Windows.Forms.Button();
            this.Wins = new System.Windows.Forms.Button();
            this.LeaderboardText = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // Back_Button
            // 
            this.Back_Button.BackColor = System.Drawing.Color.Transparent;
            this.Back_Button.BackgroundImage = global::Checkers_Game.Properties.Resources.Back_Arrow1;
            this.Back_Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Back_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Back_Button.Location = new System.Drawing.Point(12, 500);
            this.Back_Button.Name = "Back_Button";
            this.Back_Button.Size = new System.Drawing.Size(50, 50);
            this.Back_Button.TabIndex = 0;
            this.Back_Button.UseVisualStyleBackColor = false;
            this.Back_Button.Click += new System.EventHandler(this.Back_Button_Click);
            // 
            // Alphabetical
            // 
            this.Alphabetical.ForeColor = System.Drawing.Color.Black;
            this.Alphabetical.Location = new System.Drawing.Point(140, 499);
            this.Alphabetical.Name = "Alphabetical";
            this.Alphabetical.Size = new System.Drawing.Size(163, 49);
            this.Alphabetical.TabIndex = 3;
            this.Alphabetical.Text = "Alphabetical Order";
            this.Alphabetical.UseVisualStyleBackColor = true;
            this.Alphabetical.Click += new System.EventHandler(this.Alphabetical_Click);
            // 
            // Wins
            // 
            this.Wins.ForeColor = System.Drawing.Color.Black;
            this.Wins.Location = new System.Drawing.Point(491, 499);
            this.Wins.Name = "Wins";
            this.Wins.Size = new System.Drawing.Size(163, 49);
            this.Wins.TabIndex = 4;
            this.Wins.Text = "Wins";
            this.Wins.UseVisualStyleBackColor = true;
            this.Wins.Click += new System.EventHandler(this.Wins_Click);
            // 
            // LeaderboardText
            // 
            this.LeaderboardText.Location = new System.Drawing.Point(140, 12);
            this.LeaderboardText.Name = "LeaderboardText";
            this.LeaderboardText.ReadOnly = true;
            this.LeaderboardText.Size = new System.Drawing.Size(514, 481);
            this.LeaderboardText.TabIndex = 5;
            this.LeaderboardText.Text = "";
            this.LeaderboardText.TextChanged += new System.EventHandler(this.LeaderboardText_TextChanged);
            // 
            // LeaderBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Checkers_Game.Properties.Resources.Background;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.LeaderboardText);
            this.Controls.Add(this.Wins);
            this.Controls.Add(this.Alphabetical);
            this.Controls.Add(this.Back_Button);
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "LeaderBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Checkers game";
            this.Load += new System.EventHandler(this.LeaderBoard_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Back_Button;
        private System.Windows.Forms.Button Alphabetical;
        private System.Windows.Forms.Button Wins;
        private System.Windows.Forms.RichTextBox LeaderboardText;
    }
}