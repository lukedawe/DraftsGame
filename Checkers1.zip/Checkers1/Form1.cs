﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Checkers1
{
    public partial class Form1 : Form
    {

        System.Media.SoundPlayer player = new System.Media.SoundPlayer();
        public Form1()
        {
            InitializeComponent();

            
        }

        private void CloseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void HowToPlayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1. Moves are allowed only on the dark squares, so pieces always move diagonally. Single pieces are always limited to forward moves toward the opponent\n   " +
                "2.A piece making a non - capturing move(not involving a jump) may move only one square   3.A piece making a capturing move(a jump) leaps over one of the opponent's pieces, landing in a straight diagonal line on the other side. Only one piece may be captured in a single jump; however, multiple jumps are allowed during a single turn \n " +
                "4.When a piece is captured, it is removed from the board 5. If a player is able to make a capture, there is no option; the jump must be made. If more than one capture is available, the player is free to choose whichever he or she prefers \n" +
                "6. When a piece reaches the furthest row from the player who controls that piece, it is crowned and becomes a king. One of the pieces which had been captured is placed on top of the king so that it is twice as high as a single piece\n " +
                "7. Kings are limited to moving diagonally but may move both forward and backward. (Remember that single pieces, i.e. non-kings, are always limited to forward move\n " +
                "8.Kings may combine jumps in several directions, forward and backward, on the same turn. Single pieces may shift direction diagonally during a multiple capture turn, but must always jump forward (toward the opponent)");







        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Play again", "play again", MessageBoxButtons.YesNo) == DialogResult.Yes) ;

       

            

        }

      

      

      

        private void AxWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {
           // axWindowsMediaPlayer1.URL = @"c:\Users\larsaarup\documents\Music.mp3"; 

            
        }

        private void Button2_Click(object sender, EventArgs e)
        {
           // player.Play();
        }

        private void RulesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}

